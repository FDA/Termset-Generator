docker build -t termset_generation .
